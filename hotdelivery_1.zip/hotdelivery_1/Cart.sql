drop table cart;
	private String id;
	private String foodName;
	private int quantity;
	private String address;	
	private int summoney;.
	
create table cart(
	id varchar2(50),
	foodName varchar2(100),	
	quantity varchar2(100),
	address varchar2(100),
	summoney number(10)
);

select * from cart;