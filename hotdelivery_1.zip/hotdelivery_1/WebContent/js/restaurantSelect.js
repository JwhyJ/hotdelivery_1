function resClick(){
  var StoreNo="2";
  location.href='order.html'
}
